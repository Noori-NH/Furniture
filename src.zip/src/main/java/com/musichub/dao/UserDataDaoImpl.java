package com.musichub.dao;

import java.io.Serializable;
import java.util.List;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.musichub.model.User;
@Repository("userDao")
public class UserDataDaoImpl implements UserDataDao{

	@Autowired
	private SessionFactory sessionFactory;
	@Transactional(propagation=Propagation.SUPPORTS)
	public int insertRow(User u) {
		Session s = sessionFactory.openSession();  
		  Transaction tx = s.beginTransaction();  
		  s.saveOrUpdate(u);  
		  tx.commit();  
		  Serializable id = s.getIdentifier(u);  
		  s.close();  
		  return (Integer) id;  
	}

	public List<User> getList() {
		Session session = sessionFactory.openSession();  
		  @SuppressWarnings("unchecked")  
		  List<User> userList = session.createQuery("from User").list();    
		   session.close();  
		  return userList;  
	}

	public User getRowById(int id) {
		 Session session = sessionFactory.openSession();  
		 User u = (User) session.load(User.class, id);  
		  return u;  
	}
	@Transactional(propagation=Propagation.SUPPORTS)
	public int updateRow(User u) {
		Session session = sessionFactory.openSession();  
		  Transaction tx = session.beginTransaction();  
		  session.saveOrUpdate(u);  
		  tx.commit();  
		  Serializable id = session.getIdentifier(u);  
		  session.close();  
		  return (Integer) id; 
	}
	@Transactional(propagation=Propagation.SUPPORTS)
	public int deleteRow(int id) {
		Session session = sessionFactory.openSession();  
		  Transaction tx = session.beginTransaction();  
		  User u = (User) session.load(User.class, id);  
		  session.delete(u);  
		  tx.commit();  
		  Serializable ids = session.getIdentifier(u);  
		  session.close();  
		  return (Integer) ids;  
	}

}
