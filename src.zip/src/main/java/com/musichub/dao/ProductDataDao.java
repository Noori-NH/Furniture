package com.musichub.dao;

import java.util.List;

import com.musichub.model.Product;


public interface ProductDataDao {

	public int addProduct(Product p);  
	  
	 public List<Product> getProductList();  
	  
	 public Product getProdById(int id);  
	  
	 public int updateProduct(Product p);  
	  
	 public int deleteProduct(int id);  
	  
}
