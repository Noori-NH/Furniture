package com.musichub.service;

import java.util.List;

import com.musichub.model.User;

public interface UserDataService {
	 
	 public int insertRow(User u);  
	  
	 public List<User> getList();  
	  
	 public User getRowById(int id);  
	  
	 public int updateRow(User u);  
	  
	 public int deleteRow(int id);  
	 
}
