package com.musichub.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.musichub.dao.ProductDataDao;
import com.musichub.model.Product;
@Service("prodService")
public class ProductDataServiceImpl implements ProdDataService{

	@Autowired
	ProductDataDao pdataDao;
	//UserDataDaoImpl dataDaoImpl;


	@Transactional(propagation=Propagation.SUPPORTS)
	public int addProduct(Product p) {
		// TODO Auto-generated method stub
		return pdataDao.addProduct(p);
	}
	@Transactional(propagation=Propagation.SUPPORTS)
	public List<Product> getProductList() {
		// TODO Auto-generated method stub
		return pdataDao.getProductList();
	}
	@Transactional(propagation=Propagation.SUPPORTS)
	public Product getProdById(int id) {
		// TODO Auto-generated method stub
		return pdataDao.getProdById(id);
	}
	@Transactional(propagation=Propagation.SUPPORTS)
	public int updateProduct(Product p) {
		// TODO Auto-generated method stub
		return pdataDao.updateProduct(p);
	}
	@Transactional(propagation=Propagation.SUPPORTS)
	public int deleteProduct(int id) {
		// TODO Auto-generated method stub
		return pdataDao.deleteProduct(id);
	}
}