package com.musichub.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.musichub.dao.UserDataDao;
import com.musichub.model.User;

@Service("userService")
public class UserDataServiceImpl implements UserDataService {

	@Autowired
	UserDataDao dataDao;
	//UserDataDaoImpl dataDaoImpl;

	@Transactional(propagation=Propagation.SUPPORTS)
	public int insertRow(User u) {
		// TODO Auto-generated method stub
		return dataDao.insertRow(u);
	}
	@Transactional(propagation=Propagation.SUPPORTS)
	public List<User> getList() {
		// TODO Auto-generated method stub
		return dataDao.getList();
	}
	@Transactional(propagation=Propagation.SUPPORTS)
	public User getRowById(int id) {
		// TODO Auto-generated method stub
		return dataDao.getRowById(id);
	}
	@Transactional(propagation=Propagation.SUPPORTS)
	public int updateRow(User u) {
		// TODO Auto-generated method stub
		return dataDao.updateRow(u);
	}
	@Transactional(propagation=Propagation.SUPPORTS)
	public int deleteRow(int id) {
		// TODO Auto-generated method stub
		return dataDao.deleteRow(id);
	}

}
