package com.musichub.controller;

import java.io.File;
import java.io.IOException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.support.ByteArrayMultipartFileEditor;
import org.springframework.web.servlet.ModelAndView;
import com.musichub.model.Product;
import com.musichub.model.ProductValidator;
import com.musichub.model.Products;
import com.musichub.model.User;
import com.musichub.service.ProdDataService;
import com.musichub.service.UserDataService;

import java.awt.image.BufferedImage;
import java.io.*;


@Controller
public class HandleController {
	
	public HandleController()
	{
		System.out.println("Inside controller");
		

	}
	
	@Autowired
	UserDataService dataService;
	@Autowired
	ProdDataService prodService;
	//UserDataServiceImpl dataServiceImpl;
	 
	// private static String UPLOAD_LOCATION="D:\\TrainingDT\\NewBackup\\furnitures\\src\\main\\webapp\\resources\\ff\\images";
	//private ServletContext servletContext;
	  private static final Logger logger = LoggerFactory.getLogger(HandleController.class);
	 
	Products p;
	List<Products> ls;
		@RequestMapping("/")
		public ModelAndView helloWorld() {
	 
			
			return new ModelAndView("index");
		}
		
		@RequestMapping("/index")
		public String goToIndex()
		{
			return "index";
		}
		
		
		@RequestMapping("/login")
		public String goToLogin()
		{
			return "login";
		}
		
		
		  
		 @RequestMapping(value="/register",method=RequestMethod.GET)  
		 public ModelAndView getForm(@ModelAttribute User userForm) {  
		  return new ModelAndView("register").addObject("command", new User());  
		 }  
		  
		 @RequestMapping(value="/save",method=RequestMethod.POST)  
		 public ModelAndView registerUser(@ModelAttribute User userForm,ModelMap model) {  
		  //dataService.insertRow(employee); 
			 ModelAndView m1=new ModelAndView("register");
			 m1.setViewName("register");
			 dataService.insertRow(userForm);  
		  return new ModelAndView("redirect:list");  
		 }  
		  
		 @RequestMapping("list")  
		 public ModelAndView getList() {  

			 List userList = dataService.getList();
			 
			 return new ModelAndView("list", "userList", userList);  
		 }  
		  
		 
		/* @RequestMapping(value="delete",method=RequestMethod.GET)  
		 public ModelAndView deleteUser(@RequestParam int id) {  
		  //dataService.deleteRow(id); 
			 ModelAndView m1=new ModelAndView("delete");
			 m1.setViewName("delete");
			 dataService.deleteRow(id);
		  return new ModelAndView("redirect:list").addObject("command", new User());  
		 }  
		  
		 @RequestMapping(value="edit",method=RequestMethod.GET)  
		 public ModelAndView editUser(@RequestParam int id,  
		   @ModelAttribute User userForm) {  
		  //Employee employeeObject = dataService.getRowById(id);
			 
			 User u=dataService.getRowById(id);
		     ModelAndView mv=new ModelAndView("edit", "userObject",u);  
			 mv.setViewName("register");
			 return mv.addObject("command", new User());
		 }  
		  
		 @RequestMapping(value="updatepage",method=RequestMethod.POST)  
		 public ModelAndView updateUser(@ModelAttribute User userForm) {  
		 // dataService.updateRow(employee);  
			 ModelAndView mv=new ModelAndView("update");
			 
			 dataService.updateRow(userForm);
			 mv.setViewName("register");
		  return new ModelAndView("redirect:list").addObject("command", new User());  
		 }  */
		  
		/*@ModelAttribute("userForm")
		public User construct()
      {
        return new User();
		}

		@RequestMapping(value = "/register")
		public ModelAndView addUserPage() {
		ModelAndView modelAndView = new ModelAndView("register");
		modelAndView.addObject("userForm", new User());
		return modelAndView;
		}
	
		
		@RequestMapping(value ="/adduser")
		 public  String addPerson(@ModelAttribute("userForm")User u, BindingResult result)
	     {
	         
		        if(u.getUserid()==0){
		            //new person, add it
		            this.userservice.add(u);
		        }else{
		            //existing person, call update
		            this.userservice.edit(u);
		        }
		        return "redirect:/register";
	     }*/
		
		
		
		
		/*@RequestMapping(value = "/register", method = RequestMethod.GET)
		    public String listUsers(Model model) {
			 User ob=new User();
		        model.addAttribute("user", ob);
		        model.addAttribute("userlist", userservice.getAllUsers());
		        return "register";
		    }
		
		
		 
		
		     
		    @RequestMapping("/remove/{id}")
		    public String removePerson(@PathVariable("id") int id){
		         
		        this.personService.removePerson(id);
		        return "redirect:/persons";
		    }
		  
		    @RequestMapping("/edit/{id}")
		    public String editPerson(@PathVariable("id") int id, Model model){
		        model.addAttribute("person", this.personService.getPersonById(id));
		        model.addAttribute("listPersons", this.personService.listPersons());
		        return "person";
		    }
		     
		}*/
		 
		/* @RequestMapping(value = "/register", method = RequestMethod.POST)
		public String goToRegister(Map<String,Object>map)
		{
			User ob=new User();
			map.put("user", ob);
			map.put("userlist", userservice.getAllUsers());
			return "register";
		}
		@RequestMapping(value="/user.do",method=RequestMethod.POST)
		public String doActions(@ModelAttribute User user,BindingResult result,@RequestParam String action,Map<String,Object>map)
		{
			User ob=new User();
			
			return "register";
			
		}*/
		
		//@RequestMapping(value="/product",method = RequestMethod.GET,produces = {"application/json"})
     
		/*@RequestMapping("/product")
		public  ModelAndView goToProduct(HttpServletRequest re)
		{
			String val=re.getParameter("s");
			System.out.println("value="+val);
			re.setAttribute("val", val);
		
			d=new Data();
			ls=(List<Products>)d.all();
			Gson gson = new Gson();
		      String jsonProducts = gson.toJson(ls);
		      System.out.println("jsonProducts = " + jsonProducts);

		      //
		      // Converts JSON string into a collection of Student object.
		      //
		    /*  Type type = new TypeToken<List<Product>>() {
		      }.getType();
		      List<Product> pList = gson.fromJson(jsonProducts, type);
			Iterator it=ls.iterator();
			while(it.hasNext())
			{
				p=(Product)it.next();
				System.out.println("p_code="+p.getP_code()+":p_name="+p.getP_name()+":p_price="+p.getP_price()+"link="+p.getLink());
			}
			ModelAndView mv=new ModelAndView("product");
			mv.addObject("data", jsonProducts);
			return mv;
		}*/
		@RequestMapping("/aboutus")
		public String goToAboutus()
		{
			return "aboutus";
		}
		@RequestMapping("/addcart")
		public String goToAddCart(HttpServletRequest re)
		{
			String s=re.getParameter("a");
			re.setAttribute("cart", s);
			return "addcart";
		}
		
		@RequestMapping(value="/admin",method=RequestMethod.GET)  
		 public ModelAndView getProductForm(@ModelAttribute User userForm) {  
		  return new ModelAndView("admin").addObject("command", new Product());  
		 }  
		
		@Autowired
		ProductValidator productValidator;
		
		
		 @RequestMapping(value="/psave",method=RequestMethod.POST)  
		 public ModelAndView registerProd(@ModelAttribute Product prodForm,ModelMap model,@Valid Product p,BindingResult result) {
			 MultipartFile file=prodForm.getFile();
			 String fname="";
				ModelAndView m1=new ModelAndView();
				productValidator.validate(p, result);
				System.out.println("result="+result);
				if (result.hasErrors()) {
					//m1.setViewName("admin");
					
					return new ModelAndView("admin").addObject("command", new Product());  
            	   //System.out.println("result*************"+result);
            	  // m1.setViewName("admin");

    			} else {
    				
    				if (!file.isEmpty()) {
    		            try {
    		            	fname=file.getOriginalFilename();
    		                byte[] bytes = file.getBytes();
    		                BufferedOutputStream st=new BufferedOutputStream(new FileOutputStream(new File("D:\\TrainingDT\\NewBackup\\furnitures\\src\\main\\webapp\\resources\\ff\\images"+fname)));
    		                st.write(bytes);
    		                st.close();
    		                prodService.addProduct(prodForm);
    		                
    		               
    		            } 
    		                catch (Exception e) {
    		                System.out.println("You failed to upload " + fname + " => " + e.getMessage());
    		            }
    		            }
    			
    				return new ModelAndView("redirect:plist").addObject("command", new Product());
    			
    				  
    			}
			 
			
		 }  
		  
		 @RequestMapping("plist")  
		 public ModelAndView getProdList() {  

			 List prodList = prodService.getProductList();
			 
			 return new ModelAndView("plist", "prodList", prodList);  
		 }  
		  
		 
		 
		 
		 
		 
		 
		 @RequestMapping(value="delete",method=RequestMethod.GET)  
		 public ModelAndView deleteProd(@RequestParam int id) {  
		  //dataService.deleteRow(id); 
			 ModelAndView m1=new ModelAndView("delete");
			 m1.setViewName("delete");
			 prodService.deleteProduct(id);
		  return new ModelAndView("redirect:plist").addObject("command", new Product());  
		 }  
		  
		 @RequestMapping(value="edit",method=RequestMethod.GET)  
		 public ModelAndView editProduct(@RequestParam int id,  
		   @ModelAttribute Product prodForm) {  
		  //Employee employeeObject = dataService.getRowById(id);
			 
			 Product p=prodService.getProdById(id);
		     ModelAndView mv=new ModelAndView("edit", "prodObject",p);  
			 mv.setViewName("update");
			 return mv.addObject("command", new Product());
		 }  
		  
		 @RequestMapping(value="/updateprod",method=RequestMethod.POST)  
		 public ModelAndView prodUpdate(@ModelAttribute Product prodForm) {  
		 // dataService.updateRow(employee);  
			 
			// ModelAndView mv=new ModelAndView("updateprod");
			// mv.setViewName("update");
			 prodService.updateProduct(prodForm);
			 
		  return new ModelAndView("redirect:plist").addObject("command", new Product());  
		 }  
		  
		
		  
		 @RequestMapping(value="/welcome", method = RequestMethod.GET)  
		 public ModelAndView login(ModelMap model, Principal principal) {  
			  String name = principal.getName();  
			  System.out.println("welcome to login************************************");
			  model.addAttribute("author", name);  
			  model.addAttribute("message", "Welcome To Login Form Based Spring Security Example!!!");
			  //ModelAndView mv=new ModelAndView("welcome");
			  //mv.setViewName("admin");
			  //mv.addObject("command", new Product());
			  return new ModelAndView("admin").addObject("command", new Product()); 
			   
		  //return "login";  
		   
		 } 
		 
		 @RequestMapping(value="/home", method = RequestMethod.GET)  
		 public String userlogin(ModelMap model, Principal principal) {  
			  String name = principal.getName();  
			  model.addAttribute("author", name);  
			  model.addAttribute("message", "Welcome To Login Form Based Spring Security Example!!!");  
			  return "index";
			   
		  //return "login";  
		   
		 }  
		  
		 @RequestMapping(value="/userfailed", method = RequestMethod.GET)  
		 public String userfailed(ModelMap model) {  
		   
		  model.addAttribute("uerror", "Access Denied!!!");  
		  return "login";  
		   
		 } 
		   
		 @RequestMapping(value="/login_failed", method = RequestMethod.GET)  
		 public String loginerror(ModelMap model) {  
		   
		  model.addAttribute("error", "Access Denied!!!");  
		  return "login";  
		   
		 } 
		   
		 @RequestMapping(value="/logout", method = RequestMethod.GET)  
		 public String logout(ModelMap model) {  
		   
		  return "login";  
		   
		 }  
		 @RequestMapping(value="/user_logout", method = RequestMethod.GET)  
		 public String userlogout(ModelMap model) {  
		   
		  return "login";  
		   
		 }  
		 
		/* private void validateImage(MultipartFile image) {
			 if (!image.getContentType().equals("image/jpeg")) {
			 throw new RuntimeException("Only JPG images are accepted");
			 }
			 }
		 
		 public void setServletContext(ServletContext servletContext) {
		 this.servletContext = servletContext;
		  
		 }
		 
		 private void saveImage(String filename, MultipartFile image)
				 throws RuntimeException, IOException {
				 try {
				 File file = new File(servletContext.getRealPath("/") + "/"
				 + filename);
				  
				 FileUtils.writeByteArrayToFile(file, image.getBytes());
				 System.out.println("Go to the location:  " + file.toString()
				 + " on your computer and verify that the image has been stored.");
				 } catch (IOException e) {
				 throw e;
				 }
				 }*/
		 
		/* @RequestMapping(value="/singleUpload", method = RequestMethod.GET)
		    public String getSingleUploadPage(ModelMap model) {
		        Product fileModel = new Product();
		        model.addAttribute("fileBucket", fileModel);
		        return "singleFileUploader";
		    }
		 
		    @RequestMapping(value="/singleUpload", method = RequestMethod.POST)
		    public String singleFileUpload(@Valid Product fileBucket, BindingResult result, ModelMap model) throws IOException {
		 
		        if (result.hasErrors()) {
		            System.out.println("validation errors");
		            return "singleFileUploader";
		        } else {            
		            System.out.println("Fetching file");
		            MultipartFile multipartFile = fileBucket.getFile();
		 
		            //Now do something with file...
		            FileCopyUtils.copy(fileBucket.getFile().getBytes(), new File(UPLOAD_LOCATION + fileBucket.getFile().getOriginalFilename()));
		             
		            String fileName = multipartFile.getOriginalFilename();
		            model.addAttribute("fileName", fileName);
		            return "success";
		        }
		    }*/
		 
		 
}

		     


		      
	

