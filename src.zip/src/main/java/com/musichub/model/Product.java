package com.musichub.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.multipart.MultipartFile;

@Entity
public class Product {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
private int pid;
@NotEmpty(message="Product name field is mandatory.")
//@Size(max=3,message="Product name must be atleast 3 characters...")
private String pname;
//@Size(min=0,message="Product price is required")
@Min(value=1000,message="Enter valid price")
private int price;
@NotEmpty(message="Product description field is mandatory.")
//@Size(max=10,message="Product description must be atleast upto 10 characters...")
private String description;

@NotEmpty(message="Product manufacture field is mandatory.")
//@Size(max=8,message="Manufacture specification must be atleast 8 characters...")
private String manufacture;
private transient MultipartFile file;

public Product() {
	super();
}


public Product(int pid, String pname, int price, String description, String manufacture, MultipartFile file) {
	super();
	this.pid = pid;
	this.pname = pname;
	this.price = price;
	this.description = description;
	this.manufacture = manufacture;
	this.file = file;
}


public MultipartFile getFile() {
	return file;
}


public void setFile(MultipartFile file) {
	this.file = file;
}


public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}



public String getManufacture() {
	return manufacture;
}


public void setManufacture(String manufacture) {
	this.manufacture = manufacture;
}




public int getPid() {
	return pid;
}

public void setPid(int pid) {
	this.pid = pid;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}

}
