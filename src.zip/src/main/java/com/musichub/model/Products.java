package com.musichub.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Products {
	@Id
	private String p_code;
	private String p_name;
	private Double p_price;
	private String link;
	
	public Products() {
		//super();
	}
	public Products(String p_code, String p_name, Double p_price,String link) {
		//super();
		this.p_code = p_code;
		this.p_name = p_name;
		this.p_price = p_price;
		this.link=link;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getP_code() {
		return p_code;
	}
	public void setP_code(String p_code) {
		this.p_code = p_code;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public Double getP_price() {
		return p_price;
	}
	public void setP_price(Double p_price) {
		this.p_price = p_price;
	}
	

}
