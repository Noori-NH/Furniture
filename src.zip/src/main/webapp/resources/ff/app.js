
var app = angular.module('myApp',[]);
app.controller('customersCtrl', function($scope) {
    $scope.names = [
      { "Code" : "12098", "Name" : "Piano45", "Price" : "56000" },
      { "Code" : "14567", "Name" : "Piano123", "Price" : "54000" },
      { "Code" : "67589", "Name" : "Saxophone43", "Price" : "98000" },
      { "Code" : "78543", "Name" : "Electric guitar08", "Price" : "87660" },
{ "Code" : "11389", "Name" : "Saxophone98", "Price" : "198000" },
      { "Code" : "52143", "Name" : "Electric guitar12", "Price" : "98760" }

];
/*for(var keyName in $scope.names){        
     var key=keyName;
    // var value= $scope.dataSets[keyName ];

  alert(key);
  //alert(JSON.stringify(value));
}*/
});
    var app1= angular.module('myApp1',[]);
    app1.controller('customersCtrl1', function($scope) {
    $scope.pi = [
                    { "Code" : "12098", "Name" : "Piano45", "Price" : "56000" },
                    { "Code" : "14567", "Name" : "Piano123", "Price" : "54000" },
                    { "Code" : "67584", "Name" : "Piano476", "Price" : "68000" },
                    { "Code" : "43567", "Name" : "Piano678", "Price" : "78660" }
              ];
    });
    var app2 = angular.module('myApp2',[]);
    app2.controller('customersCtrl2', function($scope) {
    $scope.gu = [
                    { "Code" : "12092", "Name" : "Electric guitar04", "Price" : "66000" },
                    { "Code" : "14564", "Name" : "Electric guitar05", "Price" : "74000" },
                    { "Code" : "67589", "Name" : "Electric guitar07", "Price" : "98000" },
                    { "Code" : "78543", "Name" : "Electric guitar08", "Price" : "87660" }
              ];
});
    var app3 = angular.module('myApp3',[]);
    app3.controller('customersCtrl3', function($scope) {
    $scope.tr = [
                     { "Code" : "34092", "Name" : "Trumpet004", "Price" : "86000" },
                     { "Code" : "14568", "Name" : "Trumpet005", "Price" : "127000" },
                     { "Code" : "67589", "Name" : "Trumpet006", "Price" : "95000" },
                     { "Code" : "78543", "Name" : "Trumpet008", "Price" : "94000" }
               ];
});
    var app4 = angular.module('myApp4',[]);
    app4.controller('customersCtrl4', function($scope) {
    $scope.saxo = [
                    { "Code" : "62098", "Name" : "Saxophone67", "Price" : "96000" },
                    { "Code" : "14567", "Name" : "Saxophone78", "Price" : "84000" },
                    { "Code" : "67589", "Name" : "Saxophone43", "Price" : "91000" }
                    
              ];
});
  
   